import RomanNumerals._
import java.io.{BufferedReader, FileNotFoundException, FileReader, IOException}

/*
This is a test that reads a file containing possible inputs and compares the expected outputs with the actual outputs.
 */
object TestConverter extends App {
    println("Test SHOULD print lines:\n\n3127\n999\n7\n1990\n" +
      "V, L, D can't be followed by the same character.\n" +
      "V, L, D can't be used for substracting, in other words, they must be followed by a smaller value.\n" +
      "Symbols I, X, C, M can't be repeated more than 3 times in a row.\n" +
      "Your input can only contain I, V, X, L, C, D, M\n\n" +
      "ACTUAL OUTPUT:\n")
    try {
      val fileIn = new FileReader("target/testInputs")
      val linesIn = new BufferedReader(fileIn)
      try {
        var oneLine = ""
        while({oneLine = linesIn.readLine();oneLine != "END" && oneLine != null}){
          if(checkValidity(oneLine)){
            val decimal = convert(oneLine)
            println(decimal)
          }
        }
      } finally {
        fileIn.close()
        linesIn.close()
      }
    } catch {
      case notFound: FileNotFoundException => Console.println("FileNotFound\n")
      case e: IOException => Console.println("IOException\n")
    }
}
