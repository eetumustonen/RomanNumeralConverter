import scala.io.StdIn.readLine
import scala.collection.mutable.Buffer


/*
  This is a converter that is used for converting roman numerals to decimals.
  Start it by running the object RomanNumerals and end with a command "quit".
  The actual user interface is defined at the end of the object and it uses helper functions that are all defined below.
 */
object RomanNumerals extends App {

  /*
    This is a helper function to convert single roman numeral letters to their decimal values.
   */
  def lettersToNumbers(input: String): Buffer[Int] = {
    val ret: Buffer[Int] = Buffer()
    for(i <- 0 until input.length){
      input(i) match {
        case 'I' => ret += 1
        case 'V' => ret += 5
        case 'X' => ret += 10
        case 'L' => ret += 50
        case 'C' => ret += 100
        case 'D' => ret += 500
        case 'M' => ret += 1000
      }
    }
    ret
  }

  /*
    This is method that checks the user input to be a valid roman numeral.
    Conditions for a roman numeral to be valid are:
    1. The numeral can contain letters I, V, X, L, C, D, M.
    2. Values V, L, D can't be followed by the same value, because that would add up to the next value, e.g. V + V = X
    3. Values V, L, D can't be used for substracting, in other words, they must be followed by a smaller value.
    4. Symbols I, X, C, M can't be repeated more than 3 times in a row.
   */
  def checkValidity(input: String): Boolean = {
    val letters = Buffer('I', 'V', 'X', 'L', 'C', 'D', 'M')
    if(!input.forall(i => letters.contains(i))){
      println("Your input can only contain I, V, X, L, C, D, M")
      return false
    }
    val inputAsDec = lettersToNumbers(input)
    var sameChar = 0
    for(i <- 0 until input.length - 1){
      if(input(i) == 'V' || input(i) == 'L' || input(i) == 'D'){
        if(input(i + 1) == input(i)){
          println("V, L, D can't be followed by the same character.")
          return false
        } else if(inputAsDec(i + 1) > inputAsDec(i)){
          println("V, L, D can't be used for substracting, in other words, they must be followed by a smaller value.")
          return false
        }
      } else {
        if(input(i + 1) == input(i)){
          sameChar += 1
          if(sameChar >= 3){
            println("Symbols I, X, C, M can't be repeated more than 3 times in a row.")
            return false
          }
        } else {
          sameChar = 0
        }
      }
    }
    true
  }

  /*
    This method is used to convert the number in roman numerals to a decimal number.
    Each letter in roman numerals has a decimal value and to get the decimal value of the whole roman numeral they are all summed together with one exception.
    If a letter X is followed by a letter Y that has a greater decimal value than X, in this case value X is given it's negative value instead when counting the sum.
    There are also some restrictions for creating a roman numeral and those are checked in method checkValidity before calling this method.
  */
  def convert(input: String): Int = {
    var numberValues = lettersToNumbers(input)
      for(i <- 0 until numberValues.length - 1){
        if(numberValues(i + 1) > numberValues(i)) numberValues(i) = -numberValues(i)
      }
    numberValues.sum
  }


  /*
    This is a user interface that works in the console.
    It uses helper functions checkValidity() and convert().
  */
  var continue = true
  println("Give a Roman Numeral and I'll convert it to a decimal.\nRemember to only use the letters I, V, X, L, C, D, M.\nIf you wish to quit give the command \"quit\"\n")
  while(continue){
    print("Input: ")
    val rNum = readLine().toUpperCase
    if(rNum == "QUIT") continue = false
    else if(checkValidity(rNum)){
      val decimal = convert(rNum)
      println(decimal)
    }
  }
}
